cp best_test.last best_test.OK

